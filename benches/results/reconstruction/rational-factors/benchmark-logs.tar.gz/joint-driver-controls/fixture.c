
#include <stdint.h>
#include <stdlib.h>
#include <stddef.h>
static uint64_t calls;
void* rr_open_many(const char* p) { (void)p; calls=0; return &calls; }
void rr_close(void* p) { (void)p; }
size_t rr_inputs(void* p) { (void)p; return 1; }
size_t rr_outputs(void* p) { (void)p; return 2; }
const char* rr_input_name(void* p, size_t i) { (void)p; return i==0 ? "x" : NULL; }
const char* rr_output_name(void* p, size_t i) { (void)p; return i==0 ? "left" : i==1 ? "right" : NULL; }
uint64_t rr_calls(void* p) { (void)p; return calls; }
int rr_evaluate(void* h, uint64_t p, const uint64_t* x, size_t n, uint64_t* y) { return -1; }
int rr_evaluate_many(void* h, uint64_t p, const uint64_t* x, size_t n, uint64_t* y, size_t m) {
    (void)h; (void)x; (void)p;
    if(n!=1 || m!=2) return -1;
    ++calls;
    int status=atoi(getenv("TRACE_FIXTURE_STATUS"));
    if(status) return status;
    y[0]=1; y[1]=2;
    return 0;
}
