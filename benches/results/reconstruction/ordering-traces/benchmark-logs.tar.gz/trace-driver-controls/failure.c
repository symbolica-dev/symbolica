
#include <stdint.h>
#include <stdlib.h>
#include <stddef.h>
static uint64_t calls;
void* rr_open(const char* p) { (void)p; calls=0; return &calls; }
void rr_close(void* p) { (void)p; }
size_t rr_inputs(void* p) { (void)p; return 1; }
const char* rr_input_name(void* p, size_t i) { (void)p; (void)i; return "x"; }
uint64_t rr_calls(void* p) { (void)p; return calls; }
int rr_evaluate(void* h, uint64_t p, const uint64_t* x, size_t n, uint64_t* y) {
    (void)h; (void)p; (void)x; (void)n; (void)y; ++calls;
    return atoi(getenv("TRACE_FIXTURE_STATUS"));
}
